import json

def load_data(filename):
    with open(filename, "r", encoding="utf-8") as file:
        return json.load(file)

def get_recommendations(data, genre, decade):
    for item in data["recomend_tech"]:
        if item["genre"].lower() == genre.lower() and item["decade"] == decade:
            return item["artists"]
    return None

def show_genre_menu():
    genres = [
        "Мобильный телефон", "Планшет", "Моноблок", "Стационарный ПК", "Ноутбук"
    ]
    print("Выберите вид техники: ", ", ".join([f"{i+1}. {genre}" for i, genre in enumerate(genres)]))
    choice = int(input("Введите номер вида техники: "))
    return genres[choice - 1]

def show_decade_menu():
    decades = [
        "Работа с изображениями", "Личные задачи", "Игры", "Офисные задачи"
    ]
    print("Выберите задачу: ", ", ".join([f"{i+1}. {decade}" for i, decade in enumerate(decades)]))
    choice = int(input("Введите номер задачи: "))
    return decades[choice - 1]

def main():
    filename = "recomend_tech.json"
    data = load_data(filename)

    genre = show_genre_menu()
    decade = show_decade_menu()

    recommendations = get_recommendations(data, genre, decade)

    if recommendations is None:
        print("Нет рекомендаций по заданным параметрам.")
    else:
        print("Рекомендованная техника:", ", ".join(recommendations))

if __name__ == "__main__":
    main()
