from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_NachaloWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(881, 766)
        MainWindow.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(30, 20, 401, 691))
        font = QtGui.QFont()
        font.setFamily("Cascadia Code Light")
        font.setPointSize(20)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_4 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_4.setGeometry(QtCore.QRect(450, 20, 401, 691))
        font = QtGui.QFont()
        font.setFamily("Cascadia Code Light")
        font.setPointSize(20)
        self.pushButton_4.setFont(font)
        self.pushButton_4.setObjectName("pushButton_4")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 881, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.pushButton_2.clicked.connect(self.open_vhod_window)
        self.pushButton_4.clicked.connect(self.open_vhod_cl_window)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.pushButton_2.setText(_translate("MainWindow", "АДМИНИСТРАТОР"))
        self.pushButton_4.setText(_translate("MainWindow", "КЛИЕНТ"))

    def set_stacked_widget(self, stacked_widget):
        self.stacked_widget = stacked_widget

    def open_vhod_window(self):
        self.stacked_widget.setCurrentWidget(self.stacked_widget.widget(1))

    def open_vhod_cl_window(self):
        self.stacked_widget.setCurrentWidget(self.stacked_widget.widget(7))
