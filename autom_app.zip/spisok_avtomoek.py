from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QDialog, QMessageBox
from PyQt5.QtCore import QStringListModel
from dialog_autom import Ui_Dialog
import psycopg2

def fetch_data_from_database(query):
    try:
        conn = psycopg2.connect(
            dbname="auto_m",
            user="postgres",
            password="123456",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()
        cursor.execute(query)
        data = cursor.fetchall()
        conn.close()
        return data
    except Exception as e:
        print("Ошибка при подключении к базе данных:", e)
        return []

def insert_data_into_database(name, address):
    try:
        conn = psycopg2.connect(
            dbname="auto_m",
            user="postgres",
            password="123456",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()
        cursor.execute("INSERT INTO autom.spisok_autom (name, address) VALUES (%s, %s)", (name, address))
        conn.commit()
        conn.close()
    except Exception as e:
        print("Ошибка при добавлении данных в базу данных:", e)

def delete_data_from_database(row_id):
    try:
        conn = psycopg2.connect(
            dbname="auto_m",
            user="postgres",
            password="123456",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()
        cursor.execute("DELETE FROM autom.spisok_autom WHERE id = %s::integer", (int(row_id),))
        conn.commit()
        conn.close()
    except Exception as e:
        print("Ошибка при удалении данных из базы данных:", e)

def display_data_in_list_view(data, list_view, is_client=False):
    if is_client:
        formatted_data = [f"ID: {row[0]}, Номер телефона: {row[1]}, Пароль: {row[2]}" for row in data]
    else:
        formatted_data = [f"ID: {row[0]}, Название: {row[1]}, Адрес: {row[2]}" for row in data]
    model = QStringListModel()
    model.setStringList(formatted_data)
    list_view.setModel(model)

class Ui_SpisokAvtomoekWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(881, 766)
        MainWindow.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(30, 20, 101, 81))
        font = QtGui.QFont()
        font.setFamily("Cascadia Code Light")
        font.setPointSize(15)
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")
        self.listView = QtWidgets.QListView(self.centralwidget)
        self.listView.setGeometry(QtCore.QRect(35, 121, 801, 571))
        self.listView.setObjectName("listView")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(260, 40, 391, 41))
        font = QtGui.QFont()
        font.setFamily("Cascadia Code Light")
        font.setPointSize(25)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(740, 20, 101, 41))
        font = QtGui.QFont()
        font.setFamily("Cascadia Code Light")
        font.setPointSize(10)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(740, 60, 101, 41))
        font = QtGui.QFont()
        font.setFamily("Cascadia Code Light")
        font.setPointSize(10)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setObjectName("pushButton_3")
        self.verticalScrollBar = QtWidgets.QScrollBar(self.centralwidget)
        self.verticalScrollBar.setGeometry(QtCore.QRect(820, 120, 16, 571))
        self.verticalScrollBar.setOrientation(QtCore.Qt.Vertical)
        self.verticalScrollBar.setObjectName("verticalScrollBar")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 881, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.listView.doubleClicked.connect(self.handle_double_click)
        self.pushButton_3.clicked.connect(self.open_add_avtomoyka_dialog)
        self.pushButton_2.clicked.connect(self.delete_selected_row)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Список Автомоек"))
        self.pushButton.setText(_translate("MainWindow", "НАЗАД"))
        self.label.setText(_translate("MainWindow", "СПИСОК АВТОМОЕК"))
        self.pushButton_2.setText(_translate("MainWindow", "УДАЛИТЬ"))
        self.pushButton_3.setText(_translate("MainWindow", "ДОБАВИТЬ"))

    def handle_double_click(self, index):
        MainWindow = self.listView.window()
        MainWindow.stacked_widget.setCurrentWidget(MainWindow.menu_avtomoiky_window)

    def open_add_avtomoyka_dialog(self):
        dialog = QDialog()
        ui = Ui_Dialog()
        ui.setupUi(dialog)
        if dialog.exec_() == QDialog.Accepted:
            название = ui.textEdit.toPlainText()
            адрес = ui.textEdit_2.toPlainText()
            insert_data_into_database(название, адрес)
            self.refresh_list_view()

    def delete_selected_row(self):
        selected = self.listView.currentIndex()
        if selected.isValid():
            row_data = selected.data().split(", ")
            row_id = row_data[0].split(": ")[1]
            delete_data_from_database(row_id)
            self.refresh_list_view()
        else:
            QMessageBox.warning(None, "Ошибка", "Выберите строку для удаления")

    def refresh_list_view(self):
        query = "SELECT * FROM autom.spisok_autom"
        data = fetch_data_from_database(query)
        display_data_in_list_view(data, self.listView)

if __name__ == "__main__":
    import sys
    from PyQt5.QtWidgets import QApplication, QMainWindow, QStackedWidget

    app = QApplication(sys.argv)
    stacked_widget = QStackedWidget()
    MainWindow = QMainWindow()
    ui = Ui_SpisokAvtomoekWindow()
    ui.setupUi(MainWindow)
    stacked_widget.addWidget(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
