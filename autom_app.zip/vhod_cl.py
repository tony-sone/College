from PyQt5 import QtCore, QtGui, QtWidgets
import psycopg2

class Ui_VhodClWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(881, 766)
        MainWindow.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(140, 40, 591, 101))
        font = QtGui.QFont()
        font.setFamily("Cascadia Mono Light")
        font.setPointSize(20)
        self.label.setFont(font)
        self.label.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.label.setLineWidth(1)
        self.label.setTextFormat(QtCore.Qt.AutoText)
        self.label.setScaledContents(False)
        self.label.setIndent(10)
        self.label.setOpenExternalLinks(False)
        self.label.setObjectName("label")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(290, 450, 331, 91))
        font = QtGui.QFont()
        font.setFamily("Cascadia Code Light")
        font.setPointSize(20)
        font.setBold(False)
        font.setWeight(50)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")
        self.lineEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit.setGeometry(QtCore.QRect(290, 290, 331, 71))
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit_2 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_2.setGeometry(QtCore.QRect(290, 370, 331, 71))
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(180, 310, 101, 31))
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(180, 390, 121, 31))
        self.label_3.setObjectName("label_3")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(290, 550, 331, 91))
        font = QtGui.QFont()
        font.setFamily("Cascadia Code Light")
        font.setPointSize(20)
        font.setBold(False)
        font.setWeight(50)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setObjectName("pushButton_3")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 881, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        # Подключение кнопок к функциям
        self.pushButton_2.clicked.connect(self.login)
        self.pushButton_3.clicked.connect(self.register)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "СИСТЕМА УПРАВЛЕНИЯ АВТОМОЙКАМИ"))
        self.pushButton_2.setText(_translate("MainWindow", "ВХОД"))
        self.label_2.setText(_translate("MainWindow", "ВВЕДИТЕ ЛОГИН"))
        self.label_3.setText(_translate("MainWindow", "ВВЕДИТЕ ПАРОЛЬ"))
        self.pushButton_3.setText(_translate("MainWindow", "РЕГИСТРАЦИЯ"))

    def set_stacked_widget(self, stacked_widget):
        self.stacked_widget = stacked_widget

    def set_klient_funkcii_window(self, klient_funkcii_window):
        self.klient_funkcii_window = klient_funkcii_window

    def set_vhod_cl_window(self, vhod_cl_window):
        self.vhod_cl_window = vhod_cl_window

    def login(self):
        login = self.lineEdit.text()
        password = self.lineEdit_2.text()
        query = f"SELECT * FROM autom.klient WHERE \"Номер телефона\"='{login}' AND \"Пароль\"='{password}'"
        result = self.fetch_data_from_database(query)
        if result:
            self.show_klient_funkcii_window()
        else:
            QtWidgets.QMessageBox.warning(None, "Ошибка", "Неправильный логин или пароль")
    def register(self):
        login = self.lineEdit.text()
        password = self.lineEdit_2.text()
        if login and password:
            self.insert_data_into_database(login, password)
            QtWidgets.QMessageBox.information(None, "Успех", "Регистрация успешна")
        else:
            QtWidgets.QMessageBox.warning(None, "Ошибка", "Введите логин и пароль")

    def fetch_data_from_database(self, query):
        try:
            conn = psycopg2.connect(
                dbname="auto_m",
                user="postgres",
                password="123456",
                host="localhost",
                port="5432"
            )
            cursor = conn.cursor()
            cursor.execute(query)
            data = cursor.fetchall()
            conn.close()
            return data
        except Exception as e:
            print("Ошибка при подключении к базе данных:", e)
            return []

    def insert_data_into_database(self, login, password):
        try:
            conn = psycopg2.connect(
                dbname="auto_m",
                user="postgres",
                password="123456",
                host="localhost",
                port="5432"
            )
            cursor = conn.cursor()
            cursor.execute("INSERT INTO autom.klient (\"Номер телефона\", \"Пароль\") VALUES (%s, %s)", (login, password))
            conn.commit()
            conn.close()
        except Exception as e:
            print("Ошибка при добавлении данных в базу данных:", e)

    def show_klient_funkcii_window(self):
        if hasattr(self, 'stacked_widget') and hasattr(self, 'klient_funkcii_window'):
            self.stacked_widget.setCurrentWidget(self.klient_funkcii_window)
        else:
            print("Ошибка: 'stacked_widget' или 'klient_funkcii_window' не определены")
