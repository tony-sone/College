import sys
import psycopg2
from PyQt5.QtCore import QStringListModel, Qt, QRect
from PyQt5.QtWidgets import QApplication, QMainWindow, QStackedWidget, QMessageBox, QListView, QDialog
from vhod import Ui_VhodWindow
from knopki_1 import Ui_Knopki1Window
from spisok_avtomoek import Ui_SpisokAvtomoekWindow
from spisok_clientov import Ui_SpisokClientovWindow
from menu_avtomoiky import Ui_MenuAvtomoikyWindow
from dialog_autom import Ui_Dialog
from menu_funkciy import Ui_MenuFunkciyWindow
from nachalo import Ui_NachaloWindow
from vhod_cl import Ui_VhodClWindow
from klient_funkcii import Ui_MainWindow as Ui_KlientFunkciiWindow
import os
import datetime

class MainApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.stacked_widget = QStackedWidget()
        self.setCentralWidget(self.stacked_widget)

        self.nachalo_window = QMainWindow()
        self.ui_nachalo = Ui_NachaloWindow()
        self.ui_nachalo.setupUi(self.nachalo_window)
        self.ui_nachalo.set_stacked_widget(self.stacked_widget)
        self.nachalo_window.resize(881, 766)

        self.klient_funkcii_window = QMainWindow()
        self.ui_klient_funkcii = Ui_KlientFunkciiWindow()
        self.ui_klient_funkcii.setupUi(self.klient_funkcii_window)
        self.ui_klient_funkcii.set_stacked_widget(self.stacked_widget)
        self.klient_funkcii_window.resize(881, 766)

        self.vhod_cl_window = QMainWindow()
        self.ui_vhod_cl = Ui_VhodClWindow()
        self.ui_vhod_cl.setupUi(self.vhod_cl_window)
        self.ui_vhod_cl.set_stacked_widget(self.stacked_widget)
        self.ui_vhod_cl.set_klient_funkcii_window(self.klient_funkcii_window)
        self.vhod_cl_window.resize(881, 766)
        self.ui_klient_funkcii.set_vhod_cl_window(self.vhod_cl_window)
        self.vhod_window = QMainWindow()
        self.ui_vhod = Ui_VhodWindow()
        self.ui_vhod.setupUi(self.vhod_window)
        self.vhod_window.resize(881, 766)
        self.knopki_window = QMainWindow()
        self.ui_knopki = Ui_Knopki1Window()
        self.ui_knopki.setupUi(self.knopki_window)
        self.knopki_window.resize(881, 766)

        self.spisok_avtomoek_window = QMainWindow()
        self.ui_spisok_avtomoek = Ui_SpisokAvtomoekWindow()
        self.ui_spisok_avtomoek.setupUi(self.spisok_avtomoek_window)
        self.spisok_avtomoek_window.resize(881, 766)

        self.spisok_clientov_window = QMainWindow()
        self.ui_spisok_clientov = Ui_SpisokClientovWindow()
        self.ui_spisok_clientov.setupUi(self.spisok_clientov_window)
        self.spisok_clientov_window.resize(881, 766)

        self.menu_avtomoiky_window = QMainWindow()
        self.ui_menu_avtomoiky = Ui_MenuAvtomoikyWindow()
        self.ui_menu_avtomoiky.setupUi(self.menu_avtomoiky_window)
        self.menu_avtomoiky_window.resize(881, 766)

        self.menu_funkciy_window = QMainWindow()
        self.ui_menu_funkciy = Ui_MenuFunkciyWindow()
        self.ui_menu_funkciy.setupUi(self.menu_funkciy_window)
        self.ui_menu_funkciy.set_stacked_widget(self.stacked_widget)
        self.menu_funkciy_window.resize(881, 766)

        self.dialog_autom = QDialog()
        self.ui_dialog = Ui_Dialog()
        self.ui_dialog.setupUi(self.dialog_autom)

        self.stacked_widget.addWidget(self.nachalo_window)
        self.stacked_widget.addWidget(self.vhod_window)
        self.stacked_widget.addWidget(self.knopki_window)
        self.stacked_widget.addWidget(self.spisok_avtomoek_window)
        self.stacked_widget.addWidget(self.spisok_clientov_window)
        self.stacked_widget.addWidget(self.menu_avtomoiky_window)
        self.stacked_widget.addWidget(self.menu_funkciy_window)
        self.stacked_widget.addWidget(self.vhod_cl_window)
        self.stacked_widget.addWidget(self.klient_funkcii_window)
        self.ui_nachalo.pushButton_2.clicked.connect(self.show_vhod_window)
        self.ui_nachalo.pushButton_4.clicked.connect(self.show_vhod_cl_window)
        self.ui_vhod.pushButton_2.clicked.connect(self.check_credentials)
        self.ui_vhod.pushButton_3.clicked.connect(self.register_admin)
        self.ui_knopki.pushButton.clicked.connect(self.show_vhod_window)
        self.ui_knopki.pushButton_2.clicked.connect(self.show_spisok_avtomoek_window)
        self.ui_knopki.pushButton_4.clicked.connect(self.show_spisok_clientov_window)
        self.ui_spisok_avtomoek.pushButton.clicked.connect(self.show_knopki_window)
        self.ui_spisok_clientov.pushButton.clicked.connect(self.show_knopki_window)
        self.ui_menu_avtomoiky.pushButton.clicked.connect(self.show_spisok_avtomoek_window)
        self.ui_spisok_avtomoek.listView.doubleClicked.connect(self.show_menu_avtomoiky_window)
        self.ui_spisok_avtomoek.pushButton_3.clicked.connect(self.show_dialog_autom)
        self.ui_dialog.pushButton.clicked.connect(self.add_new_automoyka)
        self.ui_menu_avtomoiky.pushButton_7.clicked.connect(self.show_menu_funkciy_window)
        self.ui_menu_funkciy.pushButton.clicked.connect(self.show_menu_avtomoiky_window)
        self.ui_menu_avtomoiky.pushButton_3.clicked.connect(self.ui_menu_avtomoiky.create_report)

        self.load_data()
        self.center()

    def load_data(self):
        query_avtomoek = "SELECT * FROM autom.spisok_autom"
        data_avtomoek = self.fetch_data_from_database(query_avtomoek)
        self.display_data_in_list_view(data_avtomoek, self.ui_spisok_avtomoek.listView)
        query_klientov = "SELECT * FROM autom.klient"
        data_klientov = self.fetch_data_from_database(query_klientov)
        self.display_data_in_list_view(data_klientov, self.ui_spisok_clientov.listView, is_client=True)

    def center(self):
        screen = QApplication.primaryScreen().availableGeometry()
        size = self.geometry()
        self.move(int((screen.width() - size.width()) / 2),
                  int((screen.height() - size.height()) / 2))

    def show_vhod_window(self):
        self.stacked_widget.setCurrentWidget(self.vhod_window)
    def show_knopki_window(self):
        self.stacked_widget.setCurrentWidget(self.knopki_window)

    def show_spisok_avtomoek_window(self):
        self.stacked_widget.setCurrentWidget(self.spisok_avtomoek_window)

    def show_spisok_clientov_window(self):
        self.stacked_widget.setCurrentWidget(self.spisok_clientov_window)

    def show_menu_avtomoiky_window(self, index):
        self.stacked_widget.setCurrentWidget(self.menu_avtomoiky_window)

    def show_menu_funkciy_window(self):
        self.stacked_widget.setCurrentWidget(self.menu_funkciy_window)
        self.ui_menu_funkciy.load_function_data()

    def show_dialog_autom(self):
        self.dialog_autom.exec_()

    def add_new_automoyka(self):
        name = self.ui_dialog.textEdit.toPlainText()
        address = self.ui_dialog.textEdit_2.toPlainText()
        self.insert_data_into_database(name, address)
        self.ui_spisok_avtomoek.refresh_list_view()

    def register_admin(self):
        login = self.ui_vhod.lineEdit_2.text()
        password = self.ui_vhod.lineEdit.text()
        try:
            conn = psycopg2.connect(
                dbname="auto_m",
                user="postgres",
                password="123456",
                host="localhost",
                port="5432"
            )
            cursor = conn.cursor()
            cursor.execute("INSERT INTO autom.admin (login, password) VALUES (%s, %s)", (login, password))
            conn.commit()
            conn.close()
            QMessageBox.information(self, "Успех", "Регистрация успешна")
        except Exception as e:
            print("Ошибка при добавлении данных в базу данных:", e)
            QMessageBox.warning(self, "Ошибка", "Ошибка при регистрации")
    def check_credentials(self):
        login = self.ui_vhod.lineEdit_2.text()
        password = self.ui_vhod.lineEdit.text()
        query = f"SELECT * FROM autom.admin WHERE login='{login}' AND password='{password}'"
        result = self.fetch_data_from_database(query)
        if result:
            self.show_knopki_window()
        else:
            QMessageBox.warning(self, "Ошибка", "Неправильный логин или пароль")

    def fetch_data_from_database(self, query):
        try:
            conn = psycopg2.connect(
                dbname="auto_m",
                user="postgres",
                password="123456",
                host="localhost",
                port="5432"
            )
            cursor = conn.cursor()
            cursor.execute(query)
            data = cursor.fetchall()
            conn.close()
            return data
        except Exception as e:
            print("Ошибка при подключении к базе данных:", e)
            return []

    def insert_data_into_database(self, name, address):
        try:
            conn = psycopg2.connect(
                dbname="auto_m",
                user="postgres",
                password="123456",
                host="localhost",
                port="5432"
            )
            cursor = conn.cursor()
            cursor.execute("INSERT INTO autom.spisok_autom (name, address) VALUES (%s, %s)", (name, address))
            conn.commit()
            conn.close()
        except Exception as e:
            print("Ошибка при добавлении данных в базу данных:", e)
    def display_data_in_list_view(self, data, list_view, is_client=False):
        if is_client:
            formatted_data = [f"ID: {row[0]}, Номер телефона: {row[1]}, Пароль: {row[2]}" for row in data]
        else:
            formatted_data = [f"ID: {row[0]}, Название: {row[1]}, Адрес: {row[2]}" for row in data]
        model = QStringListModel()
        model.setStringList(formatted_data)
        list_view.setModel(model)

    def show_vhod_cl_window(self):
        self.stacked_widget.setCurrentWidget(self.vhod_cl_window)

    def check_login_password(self):
        login = self.ui_vhod_cl.lineEdit_2.text()
        password = self.ui_vhod_cl.lineEdit.text()
        query = f"SELECT * FROM autom.klient WHERE \"Номер телефона\"='{login}' AND \"Пароль\"='{password}'"
        result = self.fetch_data_from_database(query)
        if result:
            self.show_klient_funkcii_window()
        else:
            QMessageBox.warning(self, "Ошибка", "Неправильный логин или пароль")

    def show_klient_funkcii_window(self):
        self.stacked_widget.setCurrentWidget(self.klient_funkcii_window)

def main():
    app = QApplication(sys.argv)
    window = MainApp()
    window.resize(881, 766)
    window.center()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
