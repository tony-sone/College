from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import QStringListModel
import psycopg2
from dialog_funk import Ui_DialogFunk
class Ui_MenuFunkciyWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(881, 766)
        MainWindow.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(30, 20, 101, 81))
        font = QtGui.QFont()
        font.setFamily("Cascadia Code Light")
        font.setPointSize(15)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")
        self.listView = QtWidgets.QListView(self.centralwidget)
        self.listView.setGeometry(QtCore.QRect(35, 121, 801, 571))
        self.listView.setObjectName("listView")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(280, 40, 311, 41))
        font = QtGui.QFont()
        font.setFamily("Cascadia Code Light")
        font.setPointSize(25)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.verticalScrollBar = QtWidgets.QScrollBar(self.centralwidget)
        self.verticalScrollBar.setGeometry(QtCore.QRect(820, 120, 16, 571))
        self.verticalScrollBar.setOrientation(QtCore.Qt.Vertical)
        self.verticalScrollBar.setObjectName("verticalScrollBar")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(740, 20, 101, 41))
        font = QtGui.QFont()
        font.setFamily("Cascadia Code Light")
        font.setPointSize(10)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(740, 60, 101, 41))
        font = QtGui.QFont()
        font.setFamily("Cascadia Code Light")
        font.setPointSize(10)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setObjectName("pushButton_3")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 881, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.stacked_widget = None

        self.pushButton.clicked.connect(self.show_previous_window)
        self.pushButton_2.clicked.connect(self.delete_selected_item)
        self.pushButton_3.clicked.connect(self.open_dialog_funk)
        self.load_function_data()

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.pushButton.setText(_translate("MainWindow", "НАЗАД"))
        self.label.setText(_translate("MainWindow", "МЕНЮ ФУНКЦИЙ"))
        self.pushButton_2.setText(_translate("MainWindow", "УДАЛИТЬ"))
        self.pushButton_3.setText(_translate("MainWindow", "ДОБАВИТЬ"))

    def set_stacked_widget(self, stacked_widget):
        self.stacked_widget = stacked_widget

    def show_previous_window(self):
        if self.stacked_widget:
            self.stacked_widget.setCurrentWidget(self.stacked_widget.widget(6))
    def load_function_data(self):
        query = "SELECT id, название FROM autom.func"
        data = self.fetch_data_from_database(query)
        self.display_data_in_list_view(data)

    def fetch_data_from_database(self, query):
        try:
            conn = psycopg2.connect(
                dbname="auto_m",
                user="postgres",
                password="123456",
                host="localhost",
                port="5432"
            )
            cursor = conn.cursor()
            cursor.execute(query)
            data = cursor.fetchall()
            conn.close()
            return data
        except Exception as e:
            print("Ошибка при подключении к базе данных:", e)
            return []

    def display_data_in_list_view(self, data):
        formatted_data = [f"ID: {row[0]}, Название: {row[1]}" for row in data]
        model = QStringListModel()
        model.setStringList(formatted_data)
        self.listView.setModel(model)

    def delete_selected_item(self):
        selected_index = self.listView.currentIndex()
        if not selected_index.isValid():
            return
        item_text = selected_index.data()
        item_id = int(item_text.split(",")[0].split(":")[1].strip())

        # Удаление из базы данных
        self.delete_from_database(item_id)

        # Обновление списка
        self.load_function_data()
    def delete_from_database(self, item_id):
        query = f"DELETE FROM autom.func WHERE id = {item_id}"
        try:
            conn = psycopg2.connect(
                dbname="auto_m",
                user="postgres",
                password="123456",
                host="localhost",
                port="5432"
            )
            cursor = conn.cursor()
            cursor.execute(query)
            conn.commit()
            conn.close()
        except Exception as e:
            print("Ошибка при удалении данных из базы данных:", e)

    def open_dialog_funk(self):
        self.dialog = QtWidgets.QDialog()
        self.ui_dialog_funk = Ui_DialogFunk()
        self.ui_dialog_funk.setupUi(self.dialog)
        self.ui_dialog_funk.pushButton.clicked.connect(self.add_function)
        self.dialog.exec_()

    def add_function(self):
        func_id = self.ui_dialog_funk.lineEdit_id.text()
        func_name = self.ui_dialog_funk.lineEdit_name.text()

        if func_id and func_name:
            self.insert_data_into_database(func_id, func_name)
            self.dialog.close()
            self.load_function_data()
        else:
            QtWidgets.QMessageBox.warning(self.dialog, "Ошибка", "Пожалуйста, заполните все поля.")
    def insert_data_into_database(self, func_id, func_name):
        query = "INSERT INTO autom.func (id, название) VALUES (%s, %s)"
        try:
            conn = psycopg2.connect(
                dbname="auto_m",
                user="postgres",
                password="123456",
                host="localhost",
                port="5432"
            )
            cursor = conn.cursor()
            cursor.execute(query, (func_id, func_name))
            conn.commit()
            conn.close()
        except Exception as e:
            print("Ошибка при добавлении данных в базу данных:", e)
